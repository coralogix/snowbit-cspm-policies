import boto3
import os
import json

lambda_function_name_to_coralogix = os.getenv("lambda_function_name_to_coralogix")
cloudwatch_client = boto3.client('logs')
lambda_client = boto3.client('lambda')
account_id = boto3.client("sts").get_caller_identity()["Account"]
region = cloudwatch_client.meta.region_name


def lambda_handler(event, context):
    lambda_function_arn_to_coralogix = f"arn:aws:lambda:{region}:{account_id}:function:{lambda_function_name_to_coralogix}"
    log_group_obj = cloudwatch_client.describe_log_groups()
    if "logGroups" in log_group_obj and len(log_group_obj["logGroups"]) > 0:
        for log_group in log_group_obj["logGroups"]:
            if "logGroupName" in log_group and log_group["logGroupName"].startswith("/aws/eks/"):
                describe_subscription_filters = (
                    cloudwatch_client.describe_subscription_filters(logGroupName=log_group["logGroupName"]))
                if "subscriptionFilters" in describe_subscription_filters and len(
                        describe_subscription_filters["subscriptionFilters"]) > 0:
                    subscription_filters = describe_subscription_filters["subscriptionFilters"]

                    for subscription_filter in subscription_filters:
                        if subscription_filter and len(subscription_filter) > 0:
                            if subscription_filter["destinationArn"] == lambda_function_arn_to_coralogix:
                                cloudwatch_client.delete_subscription_filter(logGroupName=log_group["logGroupName"],
                                                                             filterName=subscription_filter[
                                                                                 "filterName"])
    try:
        lambda_function_obj = lambda_client.get_policy(FunctionName=lambda_function_name_to_coralogix)
        if lambda_function_obj and "Policy" in lambda_function_obj and len(lambda_function_obj["Policy"]) > 0:
            lambda_policy = json.loads(lambda_function_obj["Policy"])
            if "Statement" in lambda_policy and len(lambda_policy["Statement"]) > 0:
                for statement in lambda_policy["Statement"]:
                    if "Sid" in statement and len(statement["Sid"]) > 0:
                        statement_sid = statement["Sid"]
                        if statement_sid.startswith("CloudWatchFunctionPermission"):
                            lambda_client.remove_permission(FunctionName=lambda_function_name_to_coralogix,
                                                            StatementId=statement_sid)
    except lambda_client.exceptions.ResourceNotFoundException as error:
        print(f"ERROR: {error}")

    if "logGroups" in log_group_obj and len(log_group_obj["logGroups"]) > 0:
        for log_group in log_group_obj["logGroups"]:
            if "logGroupName" in log_group and log_group["logGroupName"].startswith("/aws/eks/"):
                group_name = log_group["logGroupName"]
                end_of_group_name = group_name.split("/")[-1].replace("-", "")
                lambda_client.add_permission(FunctionName=lambda_function_name_to_coralogix,
                                             StatementId=f'CloudWatchFunctionPermission-{end_of_group_name}',
                                             Action='lambda:InvokeFunction',
                                             Principal='logs.amazonaws.com',
                                             SourceArn=f"arn:aws:logs:{region}:{account_id}:log-group:{group_name}:*")
                cloudwatch_client.put_subscription_filter(logGroupName=group_name,
                                                          filterName='addGroup',
                                                          filterPattern='',
                                                          destinationArn=lambda_function_arn_to_coralogix)